# Felix Prompt (bash example)
PS1='\[\e[38;5;81m\]ƒelix \[\e[38;5;245m\]\W \[\e[0m\]» '
