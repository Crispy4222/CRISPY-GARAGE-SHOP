Felix HUD Lite — Wallpapers + Icons + Prompt
- Set wallpapers via system gallery.
- Icons (SVG/PNG) for themes/overlays.
- Prompt snippet: open ~/.bashrc and paste; restart Termux.
