CRISPY Scripts — Phone Cleanup Duo
- termux-clean.sh: cleans caches/logs safely
- storage-pass.sh: lists biggest downloads + clears DCIM/.thumbnails
Run:
curl -fsSL https://crispy4222.github.io/CRISPY-GARAGE-SHOP/scripts/termux-clean.sh | bash
curl -fsSL https://crispy4222.github.io/CRISPY-GARAGE-SHOP/scripts/storage-pass.sh | bash
