Sample pack placeholder. Replace with your real files.
